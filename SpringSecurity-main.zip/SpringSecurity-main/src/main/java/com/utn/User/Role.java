package com.utn.User;

public enum Role {
    ADMIN,
    USER
}
